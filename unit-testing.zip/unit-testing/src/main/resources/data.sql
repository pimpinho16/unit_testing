insert into item (i,name ,price, quantity ) values (1000,'Item1',10,20);
insert into item (i,name ,price, quantity ) values (1001,'Item2',15,30);
insert into item (i,name ,price, quantity ) values (1002,'Item3',20,40);