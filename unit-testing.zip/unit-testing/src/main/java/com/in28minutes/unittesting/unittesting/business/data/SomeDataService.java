package com.in28minutes.unittesting.unittesting.business.data;

public interface SomeDataService {

	public int[] retrieveAllData();




}
