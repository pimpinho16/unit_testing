package com.in28minutes.unittesting.unittesting.business;

import java.util.Arrays;
import java.util.OptionalInt;

import com.in28minutes.unittesting.unittesting.business.data.SomeDataService;

public class SomeBusinessImpl {
	
	
	private SomeDataService someDataService;
	
	public void setSomeDataService(SomeDataService someDataService) {
		this.someDataService = someDataService;
	}
/**
 * método que calcula una suma a apartir de números contenidos en un array de enteros
 * @param data (int[] data)
 * @return int suma
 */
	
	public int calculateSum(int[] data){
		
		//implementando una solución funcional o con stream (java 8)
		return Arrays.stream(data).reduce(Integer::sum).orElse(0);
		
	}
	/**
	 * método que calcula una suma a apartir de data de una implementación  
	 * 
	 * @return int suma
	 */
	public int calculateSumUsingDataService(){
		int sum =0;
		int[] data = someDataService.retrieveAllData();
		for(int value:data){
			sum+=value;
		}
		return sum;
		
	}
}
