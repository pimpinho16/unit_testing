package com.in28minutes.unittesting.unittesting.data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class Item {
	@Id
	private int i;
	private String name;
	private int price;
	private int quantity;
	
	@Transient
	private int value;
	
	
	


	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Item(int i, String name, int price, int quantity) {
		super();
		this.i = i;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}


	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getValue() {
		return value;
	}


	public void setValue(int value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return String.format("Item[%d,%s,%d,%d]",i,name,price,quantity);
	}

	

}
