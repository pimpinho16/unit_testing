package com.in28minutes.unittesting.unittesting.controller;

import org.json.JSONException;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONAssert;

public class JSonAssertTest {
	
	String actual = "{\"i\":1,\"name\":\"Ball\",\"price\":10,\"quantity\":100}";
	
	@Test
	public void jsonAssertStrictTest() throws JSONException{
		String expected = "{\"i\":1,\"name\":\"Ball\",\"price\":10}";
		//la tercer variable se refiere a si se requiere verificar toda la estructura del json o no 
		JSONAssert.assertEquals(expected, actual, false);

	}

	
	
	@Test
	public void jsonAssertNotStrictTest() throws JSONException{
		String expected = "{\"i\":1,\"name\":\"Ball\",\"price\":10,\"quantity\":100}";
		//la tercer variable se refiere a si se requiere verificar TODO el json o no 
		JSONAssert.assertEquals(expected, actual, true);

	}
	
	
	@Test
	public void jsonAssertWithoutEscapeCharactersTest() throws JSONException{
		String expected = "{i:1,name:Ball,price:10,quantity:100}";
		//la tercer variable se refiere a si se requiere verificar TODO el json o no 
		JSONAssert.assertEquals(expected, actual, true);

	}
}
