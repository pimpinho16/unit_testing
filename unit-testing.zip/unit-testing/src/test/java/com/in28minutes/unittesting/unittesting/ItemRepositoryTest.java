package com.in28minutes.unittesting.unittesting;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.unittesting.unittesting.business.data.ItemRepository;
import com.in28minutes.unittesting.unittesting.data.Item;

import junit.framework.Assert;


@RunWith(SpringRunner.class)
@DataJpaTest
public class ItemRepositoryTest {
	
	@Autowired
	ItemRepository repository;
	
	
	@Test
	public void findAllTest(){
		List<Item> items = repository.findAll();
		Assert.assertEquals(3, items.size());
	}
}
