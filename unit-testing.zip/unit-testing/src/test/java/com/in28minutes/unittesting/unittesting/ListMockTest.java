package com.in28minutes.unittesting.unittesting;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class ListMockTest {

	List<String>  mock;
	
	
	@Before
	public void setup(){
		mock =  Mockito.mock(List.class);
		
	}
	
	
	@Test
	public void basic_size() {
	
		when(mock.size()).thenReturn(5);
		Assert.assertEquals(5,mock.size());
	}

	
	@Test
	public void returnDifferentValues() {
		when(mock.size()).thenReturn(5).thenReturn(10);
		Assert.assertEquals(5,mock.size());
		Assert.assertEquals(10, mock.size());
	}

	@Test
	public void returnWithparameters() {

		when(mock.get(0)).thenReturn("in28minutes");
		Assert.assertEquals("in28minutes",mock.get(0));
		
	}
	
	
	@Test
	public void returnWithGenericParameters() {
		when(mock.get(anyInt())).thenReturn("in28minutes");
		Assert.assertEquals("in28minutes",mock.get(0));
		Assert.assertEquals("in28minutes",mock.get(0));
	}
	
	@Test
	public void verificationBasics(){
		String value =  mock.get(0);
		String value2 = mock.get(1);
		
		verify(mock).get(0);
		//verify(mock,times(0));
		

		verify(mock,times(2)).get(anyInt());
		verify(mock,atLeast(1)).get(anyInt());
		verify(mock,atMost(2)).get(anyInt());
		verify(mock,never()).get(2);
		verify(mock,atLeastOnce()).get(anyInt());
	}
	
	
	@Test
	public void argumentCapturing(){
		mock.add("SomeValue");
		
		//verification
		ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
		verify(mock).add(captor.capture());
		Assert.assertEquals("SomeValue", captor.getValue());
	}
	
	@Test
	public void multipleArgumentCapturing(){
		mock.add("SomeString");
		mock.add("SomeString2");
		
		
		ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
		//con times, decimos a verify que verifique 2 veces la acción de add para mock 
		verify(mock,times(2)).add(captor.capture());
		
		List<String> allValues = captor.getAllValues();
		Assert.assertEquals("SomeString", allValues.get(0));
		
	}
	
	/**
	 * *
	 * con spy el comportamiento permanece a diferencia de 
	 */
	@Test
	public void spying(){ 
		ArrayList arrayListSpy = spy(ArrayList.class);
		arrayListSpy.add("Test0");
		System.out.println(arrayListSpy.get(0));
		System.out.println(arrayListSpy.size());
		arrayListSpy.add("Test");
		arrayListSpy.add("Test2");	
		System.out.println(arrayListSpy.size());
		
		
		when(arrayListSpy.size()).thenReturn(5);
		System.out.println(arrayListSpy.size());
		
		
		arrayListSpy.add("Test4");
		System.out.println(arrayListSpy.size());
		
		verify(arrayListSpy).add("Test4");
	}
}
