package com.in28minutes.unittesting.unittesting.hamcrest;

public class HamcrestTest {

}
