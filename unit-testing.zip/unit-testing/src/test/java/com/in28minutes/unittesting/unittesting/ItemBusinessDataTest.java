package com.in28minutes.unittesting.unittesting;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.in28minutes.unittesting.unittesting.business.ItemBusinessService;
import com.in28minutes.unittesting.unittesting.business.data.ItemRepository;
import com.in28minutes.unittesting.unittesting.data.Item;

import junit.framework.Assert;


@RunWith(MockitoJUnitRunner.class)
public class ItemBusinessDataTest {
	
	@InjectMocks
	private ItemBusinessService business;
	
	@Mock
	private ItemRepository repository;
	
	@Test
	public void retrieveAllDataTest(){
		when(repository.findAll()).thenReturn(Arrays.asList(new Item(2,"Item 2",10,10),new Item(3,"Item 3",10,10)));
		List<Item> items = business.retrieveAllItems();
		Assert.assertEquals(items.get(0).getValue(),100);
		Assert.assertEquals(items.get(1).getValue(),100);
	}
	
	
	
	

}
